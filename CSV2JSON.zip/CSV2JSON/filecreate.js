var fs = require('fs');
var csv= fs.readFileSync('real_estate.csv','utf8').toString();
csvJSON(csv);

function csvJSON(csv)
{
var lines = csv.split("\n");
var result = [];
var headers = lines[0].split(",");

for(var i = 1; i < lines.length-1; i++)
{
var obj = {};
var currentline =lines[i].split(",");
for (var j = 0; j < headers.length; j++)
{
obj[headers[j]] =currentline[j];
}
result.push(obj);
}
//return JSON.stringify(result);
var str = JSON.stringify(result);
//str=str.replace()
//console.log(str);
fs.writeFileSync("result.json",str);
}
